# TYL

TYL - A grid-based puzzle game in development for the Rensselaer Game Showcase 2019
Created by Mason Sklar.

To play, all you need is the Game folder.
I encourage you to work your way down the list of puzzles, trying each one and exploring the quirks of each operator. Have fun!
