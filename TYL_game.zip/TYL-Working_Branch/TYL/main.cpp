#include "game.h"
#undef main

int main() {
	Game game;

	return 0;
}